#include "FindLine.h"
#include "StockRoom.h"
#include "MazeSolve.h"
#include "Charging.h"
#include "ComRead.h"
#include "ManualDrive.h"
#include <pololu/3pi.h>
#include <avr/pgmspace.h>
#include <pololu/PololuQTRSensors.h>

void drive() //Function for when the robot is in manual ride mode
{
	int escaped = 0;
	int vooruit = 100;
	int rechts = -50;
	int rechtsL = 50;
	int links = -50;
	int linksR = 50;
	int achteruit = -100;
	
	
	while(escaped == 0)
	{
		delay_us(1);
		char command = getOrder();
		switch(command)
		{
			case 4: //rechts
			vooruit = 100;
			achteruit = -100;
			links = -50;
			linksR = 50;
			if(rechtsL != 150) //increasing the speed of the robot
			{
				rechts--;
				rechtsL++;
				delay_ms(5);
			}
			set_motors(rechtsL,rechts);
			break;
			
			
			case 3: //links
			vooruit = 100;
			achteruit = -100;
			rechts = -50;
			rechtsL = 50;
			if(links != -150) //increasing the speed of the robot
			{
				linksR++;
				links--;
				delay_ms(5);
			}
			set_motors(links,linksR);
			break;
			
			
			case 2: //achteruit
			rechts = -50;
			rechtsL = 50;
			links = -50;
			linksR = 50;
			vooruit = 100;
			if(achteruit != -200) //increasing the speed of the robot
			{
				achteruit--;
				delay_ms(5);
			}
			set_motors(achteruit,achteruit);
			break;
			
			
			case 1: //vooruit
			rechts = -50;
			rechtsL = 50;
			links = -50;
			linksR = 50;
			achteruit = -100;
			if(vooruit != 200) //increasing the speed of the robot
			{
				vooruit++;
				delay_ms(5);
			}
			set_motors(vooruit,vooruit);
			break;
			
			
			case 5: //rem
			rechts = -50;
			rechtsL = 50;
			links = -50;
			linksR = 50;
			achteruit = -100;
			vooruit = 100;
			set_motors(0,0);
			break;
			
			case 6: //uit manual
			set_motors(0,0);
			escaped = 1;
			break;
			
			case 9: //lost signal
			set_motors(0,0);
			print("Signaal");
			lcd_goto_xy(0,1);
			print("kwijt");
			delay_ms(5000);
			escaped = 1;
			break;
			
			
			default:
			clear();
			print("bad cmd");
			lcd_goto_xy(0,1);
			print_hex_byte(command);
			play("o7l16crc");
			break; // bad command
		}
	}
}