#include "FindLine.h"
#include "StockRoom.h"
#include "MazeSolve.h"
#include "Charging.h"
#include "ComRead.h"
#include "ManualDrive.h"
#include <pololu/3pi.h>
#include <avr/pgmspace.h>
#include <pololu/PololuQTRSensors.h>


char buffer[100];
unsigned char read_index = 0;

char readNextByte() //skips the first part of the byte and than reads the message
{
	while(serial_get_received_bytes() == read_index)
	{}
	char ret = buffer[read_index];
	read_index ++;
	if(read_index >= 100)
	{
		read_index = 0;
	}
	return ret;
}

int getOrder() // get order from wixel
{
	int detectStartByte;
	clear();
	serial_receive_ring(buffer, 100);
	
	detectStartByte = readNextByte(); //waits for startbit
	if(detectStartByte != (char) 0x30)
	{
		return 9;
	}
	clear();
	int data = readNextByte();
	switch(data)
	{
		case(char)0x30:
		return 0;
		break;
		
		case(char)0x31:
		return 1;
		break;
		
		case(char)0x32:
		return 2;
		break;
		
		case(char)0x33:
		return 3;
		break;
		
		case(char)0x34:
		return 4;
		break;
		
		case(char)0x35:
		return 5;
		break;
		
		case(char)0x36:
		return 6;
		break;
		
		case(char)0x37:
		return 7;
		break;
		
		case(char)0x38:
		return 8;
		break;
		
		case(char)0x39:
		return 9;
		break;
	}
	return 9;
}

void receiveOrder(int *batterySim ,int *manual,int *gotLost) //receive order in integer form
{
	read_index = 0;
	int command = getOrder();
	switch(command)
	{

		case 1:; // PickupOrder
		clear();
		print("FLOEFS");
		lcd_goto_xy(0,1);
		print("ORDERS");
		play("o5 c#" );
		delay_ms(4000);
		int orderAmount = getOrder();
		print_long(orderAmount);
		delay_ms(1000);
		for(int orderIndex = 0; orderIndex < orderAmount; orderIndex++)
		{
			o1.Xorders[orderIndex] = getOrder();
			o1.Yorders[orderIndex] = getOrder();
		}
		
		for(int i = 0; i < orderAmount; i++)
		{
			clear();
			print_long(o1.Xorders[i]);
			print_character(',');
			print_long(o1.Yorders[i]);
			delay_ms(2000);
		}
		o1.packageAmount = orderAmount;
		break;
		
		case 2: // ManualOverride
		clear();
		print("FLOEFS");
		lcd_goto_xy(0,1);
		print("MANUAL");
		play("o5 c#" );
		delay_ms(4000);
		*manual = 1;
		break;
		
		case 3:; // simulateBattery
		clear();
		print("FLOEFS");
		lcd_goto_xy(0,1);
		print("BATTERY");
		play("o5 c#" );
		delay_ms(4000);
		int multiplier = getOrder();
		*batterySim = (multiplier * 10);
		clear();
		print_long(*batterySim);
		break;
		
		case 4: // Spin
		clear();
		print("FLOEFS");
		lcd_goto_xy(0,1);
		print("SPIN");
		play("o5 c#" );
		set_motors(30, -30);
		getOrder(); // wait for any command
		delay_ms(4000);
		set_motors(0,0);
		break;
		
		case 9:
		print("Signaal");
		lcd_goto_xy(0,1);
		print("kwijt");
		delay_ms(5000);
		*gotLost = 1;
		break;
	}
}

void batteryRead(unsigned int *percentage) //reads the battery percentage
{
	double average = 0;

	for(int i = 0; i < 10; i++)
	{
		double millivolts = read_battery_millivolts();
		average += millivolts;
	}
	average = average / 10;
	*percentage = average/5000*100;
}