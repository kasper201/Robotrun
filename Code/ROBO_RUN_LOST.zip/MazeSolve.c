#include "FindLine.h"
#include "StockRoom.h"
#include "MazeSolve.h"
#include "Charging.h"
#include "ComRead.h"
#include "ManualDrive.h"
#include <pololu/3pi.h>
#include <avr/pgmspace.h>
#include <pololu/PololuQTRSensors.h>

char arrayToStockroom[128] = {0};

void toStockRoom() //MazeSolve from home to stockroom
{
	int i = 0;
	int check = 0;
	while(1)
	{
		followLine(&check,1);
		turn(arrayToStockroom[i]);
		if(check == 7) //When end of maze is detected
		{
			break;
		}
		else if(check == 99) //When the end of a line is detected
		{
			break;
		}
		else if(check == 69) //when a object is detected
		{
			set_motors(0,0);
			delay_ms(1000);
		}
		i++;
	}
}

void fromStockRoom() //MazeSolve from stockroom to home
{
	int i = 0;
	int check = 0;
	while(1)
	{
		followLine(&check,1);
		if(check == 2) //When a T-left is detected the robot goes straight because it can't go right
		{
			turn(0);
		}
		else if(check == 7) //When end of maze is detected
		{
			break;
		}
		else //When none of the above is true the robot always turns right when possible
		{
			turn(1);
		}
		i++;
	}
}

void solveMaze(int *isLost) //Main solveMaze code
{
	int inMaze = 1;
	static int i = 0;
	int checkLost = 0;
		while(1)
		{
			if(checkLost >= 4);
			{
				*isLost = 1;
			}
			int crossing = 0;
			followLine(&crossing, inMaze);
			if(crossing == 7) //When end of maze is detected
			{
				checkLost = 0;
				break;
			}
			else if(crossing == 2) //When a T-left is detected, the robot goes straight because it can't go right
			{
				set_motors(0,0);
				turn(0);
				arrayToStockroom[i] = 0;
				checkLost = 0;
			}
			else if(crossing == 99) //When the end of the line is found
			{
				set_motors(0,0);
				turn(1);
				delay_ms(20);
				arrayToStockroom[i] = 2;
				checkLost++;
			}
			else //When none of the above is true, the robot always turns right when possible
			{
				set_motors(0,0);
				turn(1);
				arrayToStockroom[i] = 1;
				checkLost = 0;
			}
			i++;	
		}
}