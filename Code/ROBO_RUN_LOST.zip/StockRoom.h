#ifndef StockRoom_H_
#define StockRoom_H_

enum direction{minX, plusX, minY, plusY};
enum direction facing;

struct coords{int Xcurrent, Ycurrent, Xpackage, Ypackage;};
struct coords p1;

struct orders{int Xorders[32], Yorders[32], packageAmount;};
struct orders o1;

void stockroomRoutine(); //Main stockroom code
void findPackage(int *crossing); //Code for finding 1 package
void turnToX(int x, int ccrossing); //Making the robot face the next.package.x
void turnToY(int y, int ccrossing); //Making the robot face the next.package.y
void TurnBack();  //Driving the robot from last package to the begin of maze to return to home

#endif