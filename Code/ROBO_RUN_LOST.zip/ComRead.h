#ifndef ComRead_H_
#define ComRead_H_

char readNextByte(); //skips the first part of the byte and than reads the message
int getOrder(); //get order from wixel
void receiveOrder(int *batterySim ,int *manual, int *gotLost); //receive order in integer form
void batteryRead(unsigned int *percentage); //reads the battery percentage

#endif