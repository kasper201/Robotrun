#include "FindLine.h"
#include "StockRoom.h"
#include "MazeSolve.h"
#include "Charging.h"
#include "ComRead.h"
#include "ManualDrive.h"
#include <pololu/3pi.h>
#include <avr/pgmspace.h>
#include <pololu/PololuQTRSensors.h>

void chargeRoutine(int *isLost) //This is the order that the robot follows to go to the charging station and back
{
	int checkLost = 0;
	delay_ms(100);
	solveMaze(&checkLost);
	if(checkLost == 1)
	{
		isLost = 1;
		return;
	}
	
	delay_ms(100);
	passingToCharge();
	
	delay_ms(100);
	followCharge();
	
	clear();
	print("FLOEFS");
	lcd_goto_xy(0,1);
	print("SLEEPS");
	play("o5 c#" );
	
	delay_ms(10000);
	passingToCharge2();
	
	delay_ms(100);
	solveMaze(&checkLost);
	if(checkLost == 1)
	{
		isLost = 1;
		return;
	}
	
	delay_ms(100);
	followLine(0,0);
	set_motors(0,0);
	turn(1);
	followLine(0,0);
	set_motors(0,0);
	delay_ms(100);
}

void passingToCharge() //Passing the stockroom to go from the maze to the charging station
{
	int crossing=0;
	followLine(&crossing, 0);
	turn(1);
	while(crossing!=1)
	{
		crossing=0;
		followLine(&crossing, 0);
		if(crossing!=0) //Driving till the robot finds (0,4) in stockroom
		{
			turn(0);
		}
	}
	turn(1);
	set_motors(50, 50);
	delay_ms(200);
}

void passingToCharge2() //Passing the stockroom to go from the charging station to the maze
{
	int crossing=0;
	followLine(&crossing, 0);
	while(crossing == 69)
	{
		set_motors(0,0);
		delay_ms(2500);
		followLine(&crossing,0);
	}
	turn(3);
	while(crossing!=1)
	{
		crossing=0;
		followLine(&crossing, 0);
		if(crossing!=0)//Go straight till the coordinate (0,0) is reached in the stockroom
		{
			turn(0);
		}
	}
	turn(3);
	while(crossing!=7)
	{
		crossing=0;
		followLine(&crossing, 0);
	}
}