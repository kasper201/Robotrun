#include "FindLine.h"
#include "StockRoom.h"
#include "MazeSolve.h"
#include "Charging.h"
#include "ComRead.h"
#include "ManualDrive.h"
#include <pololu/3pi.h>
#include <avr/pgmspace.h>
#include <pololu/PololuQTRSensors.h>

enum STATE{init, stockroom, charge, manual, home, lost};
enum STATE cSTATE = init;

int main()
{
	serial_set_baud_rate(9600); // start receiving data at 115.2 kbaud
	int percentage = 100;
	int manualOverWrite = 0;
	int gotLost = 0;
	while(1)
	{
		switch(cSTATE)
		{
			case init: //init state
			clear();
			initRobot();
			delay_ms(100);
			clear();
			print("FLOEFS");
			lcd_goto_xy(0,1);
			print("WAKES");
			delay_ms(1000);
			followLine(0,0);
			set_motors(0,0);
			delay_ms(100);
			cSTATE = home;
			break;
			
			case home: // the state when it has no orders yet
			clear();
			print("FLOEFS");
			lcd_goto_xy(0,1);
			print("HOME");
			
			delay_ms(500);
			receiveOrder(&percentage ,&manualOverWrite, &gotLost);
			
			set_motors(50,50);
			delay_ms(200);
			set_motors(0,0);
			
			if(manualOverWrite == 1)
			{
				cSTATE = manual;
			}
			if(percentage<60)
			{
				cSTATE = charge;
			}
			if(o1.packageAmount>0 && percentage>=60)
			{
				cSTATE = stockroom;
			}
			if(gotLost == 1)
			{
				cSTATE = lost;
			}
			break;
			
			case stockroom: //stockroom state
			stockroomRoutine(&gotLost);
			cSTATE = home;
			break;
			
			case charge: //charge state
			chargeRoutine(&gotLost);
			percentage = 100;
			cSTATE = home;
			break;
			
			case manual: //manual state
			drive();
			cSTATE = lost;
			break;
			
			case lost: //lost state
			clear();
			print("FLOEFS");
			lcd_goto_xy(0,1);
			print("kwijt");
			play("o5 c#" );
			delay_ms(10000);
			clear();
			print("her-");
			lcd_goto_xy(0,1);
			print("start");
			break;

			default: //if no state is true
			cSTATE = lost;
			break;
		}
	}
}