#ifndef MAZESOLVE_H_
#define MAZESOLVE_H_

void toStockRoom(); //MazeSolve from home to stockroom
void fromStockRoom(); //MazeSolve from stockroom to home
void solveMaze(int *isLost); //Main zolveMaze code

#endif