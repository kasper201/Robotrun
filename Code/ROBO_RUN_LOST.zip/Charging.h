#ifndef Charging_H_
#define Charging_H_

void chargeRoutine(int *isLost); //This is the order that the robot follows to go to the charging station and back
void passingToCharge(); //Passing the stockroom to go from the maze to the charging station
void passingToCharge2(); //Passing the stockroom to go from the charging station to the maze

#endif