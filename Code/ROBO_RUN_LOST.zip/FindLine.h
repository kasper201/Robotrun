#ifndef FINDLINE_H_
#define FINDLINE_H_

int detectObstacle(); //Detecting any obstacle thats in front of the robot while riding across a line
void initRobot(); //Calibrating the robot to be on top of the line and initialize the sensors. Then driving to starting point for accact coordinates of the robot
void checkReachedTurn(); //When turning this function is to detect a line while turning to know how much further it needs to go
void turn(int turnTo); //Turns the robot to the asked position
void followCharge(); //Follow line but then without crossings to prevent wrong readings when ending ar chargingpoint
void followLine(int *typeOfCrossing, int inMaze); //0 if no crossing 99 if off of line

#endif