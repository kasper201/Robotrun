#ifndef MAZESOLVE_H_
#define MAZESOLVE_H_

void solveMaze();

#endif // SOLVEMAZE